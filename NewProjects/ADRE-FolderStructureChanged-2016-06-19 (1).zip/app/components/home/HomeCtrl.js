(function (angular, _) {
    "use strict"
    var hm = angular.module('homeCtrl', []);
    hm.controller("HomeCtrl", HomeCtrl);

    function HomeCtrl($scope){
                
    }

})(window.angular);