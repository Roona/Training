
/**
 * @author 		:	Roona
 * @Date 		:	June, 6 , 2016
 * @FileName	:	AdreConstants.js
 */

var AdreConstants = function(){
	
	// Keywords
	this.ENGAGEMENT = "Engagement";
	this.CAPACITY = "Capacity";
	
	// Engagement COnstants
	this.ABOUT_US = "About Us";
	this.WHAT_WE_DO  = "What We Do";
	this.WHY_WE_CHOOOSE = "Why We Choose Us";
	
	// Tabs
	this.TAB_HOME = "Home";
	this.TAB_ENGAGEMENT = "Engagement";
	this.TAB_CAPACITY = "Capacity";
	this.TAB_LOGIN = "Login";
	
	this.TAB_ENGAGEMENT_QUES="Engagement Question";
	this.TAB_CAPACITY_QUES="Capacity Question";
	this.TAB_ENAGAGEMENT_TAB="Engagement";
};
	


var adreConstants = new AdreConstants();

