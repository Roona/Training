(function(angular) {
	"use strict"
    
	var adreApp = angular.module('adre', ['ngRoute']);
    
    adreApp.config(['$routeProvider',  function($routeProvider, $location) {
            $routeProvider
            .when('/Home', {
                templateUrl: 'Home.html',
                controller: "menuCtrl",
                // controllerAs: "cfgCtrl"
            })
            .when('/Register', {
                    templateUrl: 'Registration.html',
                    controller: 'registrationCtrl',                    
                    pageTitleNotBuiltIn: "Register"
            })
            .when('/Admin', {
                    templateUrl: 'Admin.html',
                    controller: 'adminCtrl',
                    pageTitleNotBuiltIn: "Admin"
            })
            .when('/Help', {
                templateUrl: 'Help.html',
                controller: 'helpCtrl',
                pageTitleNotBuiltIn: "Help"
            })
            .otherwise({
                redirectTo: '/Home'
            });
        }
    ]);
    
    adreApp.controller('menuCtrl', function ($scope, $location) {
	    $scope.isActive = function (path) {
	        return $location.path() === path;
	    }
	 });
    
    adreApp.controller('registrationCtrl', function ($scope) {		
        //this to be replaced with a service that pulls data from ITG if possible	
		$scope.eais = [
            {
                eaiName: 'Revenue',
                preload: 'true'
            },
            {
                eaiName: 'Dot Com',
                preload: 'true'
            },
            {
                eaiName: 'CloudOps',
                preload: 'true'
            }
        ];
        $scope.addedEais = [];
        
        $scope.moveItem = function(item, from, to) {
            var idx=from.indexOf(item);
            if (idx != -1) {
                if(from[idx].preload == 'true') {
                    from.splice(idx, 1);
                    to.push(item);
                } else {
                    from.splice(idx, 1);
                }      
            }
        };
        
        $scope.moveAll = function(from, to) {
            angular.forEach(from, function(item) {
                var idx=from.indexOf(item);
                if (idx != -1) {
                    if(from[idx].preload == 'true') {
                        to.push(item);
                    }
                }
            });
            from.length = 0;
        };
        
        $scope.addCustomEai = function () {

            $scope.addedEais.push({
                eaiName: $scope.customEai,
                preload: 'false'
                
            });

            // Clear input fields after push
            $scope.customEai = "";
        };        
        
        $scope.vps = [
            {
                name: 'Don Fike'
            },
            {
                name: 'Gary Bronson'
            },
            {
                name: 'Michael Lauderdate'
            }
        ];
        $scope.selectedVp = [];      
	});
    
    adreApp.controller('adminCtrl', function ($scope) {			
		$scope.message = "The app routing is working!";
	});
    
    adreApp.controller('helpCtrl', function ($scope) {			
		$scope.message = "The app routing is working!";
	});
        
		// .directive("Configure", function() {
		// 	return {
		// 		retrict: "AEC",
		// 		templateUrl: "Configure.html",
		// 		scope: {
		// 			entity: "="
		// 		}
		// 	}
		// })    
})(window.angular);