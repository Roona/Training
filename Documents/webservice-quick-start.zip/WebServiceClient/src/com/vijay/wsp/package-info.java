@javax.xml.bind.annotation.XmlSchema(namespace = "http://wsp.vijay.com/")
package com.vijay.wsp;
